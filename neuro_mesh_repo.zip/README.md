# NeuroMesh

**NeuroMesh** is a peer‑to‑peer intelligence marketplace inspired by projects like
Bittensor.  It provides an open network where **miners** supply models or
inference services, **validators** evaluate those services, and a
weight‑based consensus mechanism distributes rewards to the most
productive participants.  The system is designed around a permissionless
appchain (NeuroChain), specialized task arenas called **subnets**, and a
public API that allows integrators to consume high‑quality intelligence
without trusting a central provider.

This repository contains the reference implementation of the NeuroMesh
protocol.  It is structured as a **monorepo** with Rust code for the
Substrate‑based chain, Python clients for miners and validators, a
TypeScript aggregator service, and supporting scripts and tests.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Repository Structure](#repository-structure)
3. [Architecture Overview](#architecture-overview)
4. [Development](#development)
5. [Testing](#testing)
6. [Contributing](#contributing)

## Getting Started

To clone the repository and install dependencies, run:

```bash
git clone https://github.com/YOUR_ORG/neuro_mesh.git
cd neuro_mesh
# install Rust toolchain
rustup toolchain install stable
rustup default stable
# install Node dependencies for the aggregator
cd src/aggregator && npm install
cd ../../
# install Python dependencies for miner/validator clients
python3 -m venv .venv && source .venv/bin/activate
pip install -r src/miner/requirements.txt
pip install -r src/validator/requirements.txt
```

> **Note:** Some components are only skeletons at this stage.  Please refer to
> the [backlog](docs/backlog.md) for planned features and issues.

## Repository Structure

```text
neuro_mesh/
├── src/                # Source code for all components
│   ├── chain/          # Substrate runtime and pallets (Rust)
│   ├── node/           # libp2p networking layer (Rust)
│   ├── miner/          # Reference miner client (Python)
│   ├── validator/      # Reference validator client (Python)
│   ├── aggregator/     # Public API and routing service (TypeScript)
│   └── sdk/            # Client SDKs (Rust and Python)
├── docs/               # Technical architecture, specs, and backlog
├── scripts/            # Helper scripts for setup and development
├── test/               # Unit, integration and end‑to‑end tests
├── .github/
│   └── workflows/      # Continuous integration configuration
├── .gitignore          # Files and directories ignored by git
├── foundry.toml        # Placeholder for any Foundry configuration
└── Cargo.toml          # Top‑level cargo workspace configuration
```

### Chain (`src/chain`)

The chain is a Substrate runtime that defines the core pallets for
NeuroMesh, including account balances, staking, subnet registry, miner
and validator registries, emissions, and consensus mechanisms.  See
[`src/chain/README.md`](src/chain/README.md) for more details.

### Node (`src/node`)

Provides the libp2p networking layer used by miners and validators to
discover each other.  This component includes the gRPC/HTTP servers
exposed by miners for inference and by validators for evaluation
coordination.

### Miner (`src/miner`)

The reference miner client demonstrates how to expose an inference
endpoint for a given subnet.  It includes a minimal Python program
wrapped in gRPC and uses the NeuroChain SDK to register and submit
metadata to the chain.

### Validator (`src/validator`)

The reference validator client implements the sampling and scoring
protocol.  Validators query miners, compute scores using the subnet’s
evaluation logic, and submit weight vectors on‑chain.

### Aggregator (`src/aggregator`)

This TypeScript service implements the public API.  It fetches
current weight matrices from the chain, selects top‑ranked miners for
queries, routes requests, and aggregates responses according to
configured strategies.

### SDK (`src/sdk`)

Client SDKs for interacting with NeuroChain from Rust and Python.  The
SDKs wrap RPC calls, provide type‑safe models, and simplify on‑chain
interactions for miners, validators, and integrators.

## Architecture Overview

The architecture of NeuroMesh has several key components:

* **NeuroChain** – a Substrate‑based appchain that stores the global
  state: account balances, subnets, registrations, weight matrices,
  reputation scores, and emissions schedules.
* **Subnets** – logical “arenas” for specific tasks (code generation,
  vision generation, protein folding, etc.).  Each subnet defines
  schemas and evaluation specs.
* **Miners** – nodes that host AI models or pipelines.  They accept
  inference requests via gRPC/HTTP and earn rewards proportional to
  their weight in the subnet.
* **Validators** – nodes that sample miners, evaluate outputs and
  compute weight vectors.  Validator reputation is updated based on
  agreement with global consensus.
* **Aggregator** – a public service that routes queries from
  integrators to the best‑ranked miners and aggregates results.
* **Consensus** – a weight‑based mechanism inspired by Yuma; miners
  earn rewards based on the aggregate weight assigned by validators,
  while validators themselves are scored on alignment with
  consensus.

For a complete description of the protocol, see the
[architecture document](docs/architecture.md) and the original PRD.

## Development

This repository is organized as a **multi‑language workspace**.  To
build and run the components:

* **Rust (chain & node)** – run `cargo build` in the project root to
  compile the chain and node crates.  You will need the
  [Substrate prerequisites](https://docs.substrate.io/install/) installed.
* **Python (miner & validator)** – see `src/miner/README.md` and
  `src/validator/README.md` for instructions on running the reference
  clients.  They require Python 3.10+.
* **TypeScript (aggregator)** – from `src/aggregator`, run
  `npm install && npm run build` to compile the aggregator service.  A
  sample `docker-compose.yml` is provided in `scripts/`.

## Testing

Each component includes its own unit and integration tests:

* For Rust crates, run `cargo test` in the respective directory.
* For Python clients, run `pytest -q` from the project root.
* For the aggregator, run `npm test`.

A top‑level CI workflow defined in `.github/workflows/ci.yml` runs
formatting checks (`rustfmt`, `black`, `prettier`), lints (`clippy`,
`flake8`, `eslint`), and tests across the entire workspace.  See
[ci.yml](.github/workflows/ci.yml) for details.

## Continuous Integration

We use [GitHub Actions](https://github.com/features/actions) to
automatically test and lint every change.  On each push or pull
request, the workflow performs the following steps:

1. Checks out the repository and installs the Rust, Python, and
   Node.js toolchains.
2. Installs dependencies for each component.
3. Runs unit and integration tests across all languages.
4. Reports failures, preventing broken code from being merged into
   `main`.

To reproduce the CI environment locally, run the provided helper
script:

```bash
bash scripts/run_tests.sh
```

This script orchestrates Rust tests via `cargo`, Python tests via
`pytest`, and TypeScript tests via `npm test`.

## Contributing

Contributions are welcome!  Please read the
[contributing guidelines](docs/CONTRIBUTING.md) and review the
[backlog](docs/backlog.md) to understand current priorities.  When
opening a pull request, reference the associated issue using
`Closes #<issue-number>` and follow the coding standards described
therein.

---

© 2025–2026 NeuroMesh Contributors.  See [LICENSE](LICENSE) for
licensing information.