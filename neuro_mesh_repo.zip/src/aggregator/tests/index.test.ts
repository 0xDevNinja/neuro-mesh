import { describe, it, expect } from '@jest/globals';

describe('aggregator', () => {
  it('sanity test', () => {
    expect(1 + 1).toBe(2);
  });
});